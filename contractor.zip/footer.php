<footer class="site-footer">
          <div class="text-center" style="text-align: center">
              2017  &copy;Adroits
              <a href="#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
