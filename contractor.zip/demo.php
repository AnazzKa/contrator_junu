<?php
$a=5;
$a.=7;
echo $a;
