<?php
/*if(!isset($_SESSION))
{
	session_start();
}*/
if (session_status() === PHP_SESSION_NONE)
{
	session_start();
}
?>